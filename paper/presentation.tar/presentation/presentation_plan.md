

- Virtualization
  - diagram
  - pros
  - cons
- Containerization
  - diagram
  - software
  - pros
  - cons
- Containerization security
  - security issues
- Solutions
  - Virtulization
  - Namespaces
  - SELinux
  - Cgroups
  - Layers Diagram

- Qemu/KVM Web UI
  - Why?
  - screenshots
  - How to use it

- Application
  - Testing Security
    - SELinux
    - Cgroups
    - Virtualizaion
